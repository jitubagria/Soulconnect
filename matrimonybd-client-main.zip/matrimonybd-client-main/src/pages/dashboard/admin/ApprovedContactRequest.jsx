const ApprovedContactRequest = () => {
    return (
        <div>
            Approved Contact Request!!
        </div>
    );
};

export default ApprovedContactRequest;