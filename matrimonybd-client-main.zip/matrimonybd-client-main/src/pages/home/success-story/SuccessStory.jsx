const SuccessStory = () => {
    return (
        <div>SuccessStory</div>
    )
}

export default SuccessStory